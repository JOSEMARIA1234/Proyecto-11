var sea,seaImg;
var ship,shipImg;

var seaSound;

function preload(){

seaImg = loadImage("sea.png");

shipImg = loadAnimation("ship-1.png","ship-2.png","ship-3.png","ship-4.png");

seaSound = loadSound("MAR.mp3");

}

function setup(){
  createCanvas(1000,400);

  sea = createSprite(500,200,600,20);
  sea.addImage("seaImage",seaImg);
  sea.scale=0.2399;

  ship = createSprite(200,250,40,40);
  ship.addAnimation("shipAnimation",shipImg);
  ship.scale=0.2;

}

function draw() {
  background("blue");

  if(keyDown(74)){
    ship.velocityX = -2;
  }

  if(keyDown(76)){
    ship.velocityX = 2;
  }

  if(keyDown(75)){
    ship.velocityX = 0;
  }

  if(keyDown("left")){
    ship.velocityX = -2;
  }

  if(keyDown("right")){
    ship.velocityX = 2;
  }

  if(keyDown("down")){
    ship.velocityX = 0;
  }

  seaSound.play();
 

  drawSprites();
}
